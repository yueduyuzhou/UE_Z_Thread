#pragma once

#include "CoreMinimal.h"

#if PLATFORM_WINDOWS
struct ZTHREAD_API FWindowsPlatformThread
{
	static void Show();
	static void Hide();
	static bool IsShown();

	static FSimpleDelegate CompletedDelegate;
	static FSimpleDelegate RunDelegate;

};
#endif