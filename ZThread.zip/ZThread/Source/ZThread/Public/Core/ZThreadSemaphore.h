#pragma once

#include "CoreMinimal.h"

struct ZTHREAD_API FZThreadSemaphore
{
	FZThreadSemaphore();
	virtual ~FZThreadSemaphore();

	virtual void Trigger();
	virtual bool Wait(uint32 WaitTime, const bool bIgnoreThreadIdleStats = false);
	bool Wait();

private:

	FEvent*				EventSemaphore;
	uint8				bWait;
};