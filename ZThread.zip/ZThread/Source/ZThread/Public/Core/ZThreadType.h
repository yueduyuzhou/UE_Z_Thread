#pragma once

#include "CoreMinimal.h"
#include "Templates/SharedPointer.h"

typedef TFunction<void()> FLambda;

struct ZTHREAD_API FZThreadHandle : public TSharedFromThis<FZThreadHandle>
{
public:
	FZThreadHandle();

	FORCEINLINE bool IsValid()
	{
		return bIsValid;
	}

	FORCEINLINE bool operator==(const FZThreadHandle& InHandle)
	{
		return (InHandle.GID_A == GID_A) 
			&& (InHandle.GID_A == GID_B) 
			&& (InHandle.GID_A == GID_C) 
			&& (InHandle.GID_A == GID_D);
	}
private:
	uint64 GID_A;
	uint64 GID_B;
	uint64 GID_C;
	uint64 GID_D;

	bool bIsValid;
};

enum class ZTHREAD_API EThreadState
{
	THREADLISURELY,
	THREADWORKING,
	THREADERROR
};