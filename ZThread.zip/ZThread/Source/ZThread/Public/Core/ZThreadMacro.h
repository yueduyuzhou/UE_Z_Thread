
#ifdef PLATFORM_WINDOWS
	#include<iostream>
	#include<thread>
	#define CPUThreadNumber std::thread::hardware_concurrency()
#else
	#defnien CPUThreadNumber 32
#endif


/* �������� */
#define MUTEX_LOCK FScopeLock ScopeLock(&Mutex)

/************************************************************
*	�첽
************************************************************/
#define USE_ABANDONABLETHREAD_ASYNC(InThreadDelegate) \
(new FAutoDeleteAsyncTask<FZAbandonable> AsyncAbandThread)->StartBackgroundTask();

#define ASYNC_RAW(InObj, InMethod, ...) \
USE_ABANDONABLETHREAD_ASYNC(FSimpleDelegate::CreateRaw(InObj, InMethod, __VA_ARGS__));

#define ASYNC_UOBJ(InObj, InMethod, ...) \
USE_ABANDONABLETHREAD_ASYNC(FSimpleDelegate::CreateUObject(InObj, InMethod, __VA_ARGS__));

#define ASYNC_SP(InObj, InMethod, ...) \
USE_ABANDONABLETHREAD_ASYNC(FSimpleDelegate::CreateSP(InObj, InMethod, __VA_ARGS__));

#define ASYNC_LAMBDA(InMethod, ...) \
USE_ABANDONABLETHREAD_ASYNC(FSimpleDelegate::CreateLambda(InMethod, __VA_ARGS__));

#define ASYNC_UFUNC(InObj, InMethod, ...) \
USE_ABANDONABLETHREAD_ASYNC(FSimpleDelegate::CreateUFunction(InObj, InMethod, __VA_ARGS__));

/************************************************************
*	ͬ��
************************************************************/
#define USE_ABANDONABLETHREAD_SYNC(InThreadDelegate) \
{FAsyncTask<FZAbandonable>* SyncAbandThread = new FAsyncTask<FZAbandonable>(InThreadDelegate); \
SyncAbandThread->StartBackgroundTask(); \
SyncAbandThread->EnsureCompletion(); \
delete SyncAbandThread;}

#define SYNC_RAW(InObj, InMethod, ...) \
USE_ABANDONABLETHREAD_SYNC(FSimpleDelegate::CreateRaw(InObj, InMethod, __VA_ARGS__));

#define SYNC_UOBJ(InObj, InMethod, ...) \
USE_ABANDONABLETHREAD_SYNC(FSimpleDelegate::CreateUObject(InObj, InMethod, __VA_ARGS__));

#define SYNC_SP(InObj, InMethod, ...) \
USE_ABANDONABLETHREAD_SYNC(FSimpleDelegate::CreateSP(InObj, InMethod, __VA_ARGS__));

#define SYNC_LAMBDA(InMethod, ...) \
USE_ABANDONABLETHREAD_SYNC(FSimpleDelegate::CreateLambda(InMethod, __VA_ARGS__));

#define SYNC_UFUNC(InObj, InMethod, ...) \
USE_ABANDONABLETHREAD_SYNC(FSimpleDelegate::CreateUFunction(InObj, InMethod, __VA_ARGS__));

/************************************************************
*	
************************************************************/
#define CALL_SYNC_THREAD(InCallThread, InOtherTask, InCode) \
{FGraphEventRef NewTask = FFunctionGraphTask::CreateAndDispatchWhenReady([&]() {InCode}, TStatId(), InOtherTask, InCallThread); \
FTaskGraphInterface::Get().WaitUntilTaskCompletes(NewTask);}

#define CALL_ASYNC_THREAD(InCallThread, InOtherTask, InCode) \
FFunctionGraphTask::CreateAndDispatchWhenReady([&]() {InCode}, TStatId(), InOtherTask, InCallThread); 

/************************************************************
*
************************************************************/
#define CALL_THREAD(OutEventRef, InDelegate, InOtherTask) \
OutEventRef = FSimpleDelegateGraphTask::CreateAndDispatchWhenReady(InDelegate, TStatId(), InOtherTask);

#define CALL_THREAD_UOBJ(OutEventRef, InOtherTask, InObj, InMethod, ...) \
CALL_THREAD(OutEventRef, InOtherTask, FSimpleDelegate::CreateUObject(InObj, InMethod, __VA_ARGS__));

#define CALL_THREAD_SP(OutEventRef, InOtherTask, InSP, InMethod, ...) \
CALL_THREAD(OutEventRef, InOtherTask, FSimpleDelegate::CreateSP(InSP, InMethod, __VA_ARGS__));

#define CALL_THREAD_RAW(OutEventRef, InOtherTask, InRaw, InMethod, ...) \
CALL_THREAD(OutEventRef, InOtherTask, FSimpleDelegate::CreateRaw(InRaw, InMethod, __VA_ARGS__));

#define CALL_THREAD_LAMBDA(OutEventRef, InOtherTask, InMethod, ...) \
CALL_THREAD(OutEventRef, InOtherTask, FSimpleDelegate::CreateLambda(InMethod, __VA_ARGS__));

#define CALL_THREAD_UFUNCTION(OutEventRef, InOtherTask, InFunc, InFuncName, ...) \
CALL_THREAD(OutEventRef, InOtherTask, FSimpleDelegate::CreateUFunction(InFunc, InFuncName, __VA_ARGS__));

/************************************************************
*
************************************************************/
#define WAITING_OTHER_THREADS_COMPLETED(InEventRef) \
FTaskGraphInterface::Get().WaitUntilTaskCompletes(InEventRef);

#define WAITING_OTHER_THREADS_COMPLETED_MULTI(InEventRef) \
FTaskGraphInterface::Get().WaitUntilTasksComplete(InEventRef);

#if 0
/************************************************************
*
************************************************************/
class ZTHREAD_API FRenderThread
{
public:

	static ENamedThreads::Type GetDesiredThread()
	{
		check(!GIsThreadedRendering || ENamedThreads::GetRenderThread() != ENamedThreads::GameThread);
		return ENamedThreads::GetRenderThread();
	}

	static ESubsequentsMode::Type GetSubsequentsMode()
	{
		return ESubsequentsMode::FireAndForget;
	}
};

#define DOTASK_THREAD(InCode) \
void DoTask(ENamedThreads::Type InCurrentThread, FGraphEventRef& INCompletionGraphEvent) \
{FRHICommandListImmediate& RHIComList = GetImmediateCommandList_ForRenderCommand(); \
InCode;} \

#define DOTASK_THREAD_ID(InTypeName) \
FORCEINLINE TStatId GetStatId() const \
{RETURN_QUICK_DECLARE_CYCLE_STAT(InTypeName, STATGROUP_RenderThreadCommandws);} 
#endif