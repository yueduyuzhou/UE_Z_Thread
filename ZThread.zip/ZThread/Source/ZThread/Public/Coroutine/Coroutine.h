#pragma once

#include "CoreMinimal.h"
#include "Core/ZThreadType.h"
#include "Templates/SharedPointer.h"

struct ZTHREAD_API FCoroutineRequest
{
public:

	FCoroutineRequest(const float InIntervalTime);

	bool bCompleteRequest;
	float IntervalTime;
};

class ZTHREAD_API ICoroutineObj : public TSharedFromThis<ICoroutineObj>
{
	friend class ICoroutineContainer;

public:

	ICoroutineObj();
	virtual ~ICoroutineObj() {}

	bool operator== (const ICoroutineObj& InCoroutineObj)
	{
		return this->Handle == InCoroutineObj.Handle;
	}

	/* ��Ǵ�����Ҫ���� */
	FORCEINLINE void Awaken() { bAwaken = true; }

protected:

	virtual void Update(FCoroutineRequest& InCoroutineRequest) = 0;

protected:
	
	/* ���Խ��о�̬ע�� */
	static TArray<TSharedPtr<ICoroutineObj>> CoroutineObjArray;

	uint8 bAwaken;
	FZThreadHandle Handle;
};

typedef TWeakPtr<ICoroutineObj> FCoroutineHandle;

class ZTHREAD_API FCoroutineObj : public ICoroutineObj
{
public:

	FCoroutineObj(const FSimpleDelegate& InDelegate);
	FCoroutineObj(const float InTotalTime, const FSimpleDelegate& InDelegate);

protected:

	/* �жϴ����Ƿ����ִ�У�ִ�к��־��� */
	virtual void Update(FCoroutineRequest& InCoroutineRequest) final;

private:

	FSimpleDelegate Delegate;
	const float TotalTime;
	float RuningTime;

};