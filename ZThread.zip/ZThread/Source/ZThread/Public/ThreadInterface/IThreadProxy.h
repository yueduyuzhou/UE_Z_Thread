#pragma once

#include "CoreMinimal.h"
#include "Core/ZThreadType.h"

class ZTHREAD_API IThreadProxy : public TSharedFromThis<IThreadProxy>
{
public:
	IThreadProxy();
	virtual ~IThreadProxy();

	FORCEINLINE FSimpleDelegate GetDelegate() { return ThreadDelegate; }
	FORCEINLINE TSharedRef<FZThreadHandle> GetThreadHandle() { return ThreadHandle.ToSharedRef(); }

	virtual void CreateSafeThread() = 0;
	virtual void WakeupThread() = 0;
	virtual bool IsSuspend() = 0;
	virtual void WaitAndCompleted() = 0;
	virtual void BlockingAndCompletion() = 0;

protected:

	FSimpleDelegate ThreadDelegate;

private:
	TSharedPtr<FZThreadHandle> ThreadHandle;
};
