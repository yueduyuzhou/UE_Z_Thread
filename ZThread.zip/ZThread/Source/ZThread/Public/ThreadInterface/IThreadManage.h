#pragma once

#include "CoreMinimal.h"
#include "Core/ZThreadMacro.h"
#include "AbandonableThread/AbandonableThread.h"
#include "Coroutine/Coroutine.h"
#include "Engine/StreamableManager.h"
#include "IThreadProxy.h"
#include "RunnableThread/RunnableThread.h"

struct FStreamableHandle;

class ZTHREAD_API IThreadContainer
{
public:

	IThreadContainer() {}
	virtual ~IThreadContainer() {}

protected:

	FCriticalSection Mutex;
};

class ZTHREAD_API IThreadProxyContainer : public TArray<TSharedPtr<IThreadProxy>>, public IThreadContainer
{
protected:
	typedef TArray<TSharedPtr<IThreadProxy>> TProxyArray;

public:

	IThreadProxyContainer() {}
	virtual ~IThreadProxyContainer() {}

public:
	
	/* �����̵߳��̳߳� */
	IThreadProxyContainer& operator<< (const TSharedPtr<IThreadProxy>& InThreadProxy)
	{
		MUTEX_LOCK;

		//����һ���߳�
		InThreadProxy->CreateSafeThread();

		this->Add(InThreadProxy);

		return *this;
	}

	/* ���̳߳�����һ�����е��̲߳��󶨴��� */
	IThreadProxyContainer& operator>> (const FSimpleDelegate& InDelegate)
	{
		FZThreadHandle ThreadHandle;

		{
			MUTEX_LOCK;
			for (auto& Tmp : *this)
			{
				if (Tmp->IsSuspend() && !Tmp->GetDelegate().IsBound())
				{
					Tmp->GetDelegate() = InDelegate;
					ThreadHandle = Tmp->GetThreadHandle().Get();
					break;
				}
			}
		}

		if (!ThreadHandle.IsValid())
		{
			//����һ���Զ�������߳�
			*this << MakeShareable(new FZThreadRunnable(true)) << InDelegate;
		}

		return *this;
	}

	/* ���̳߳�����һ�����е��̲߳��󶨴��� */
	FZThreadHandle operator<< (const FSimpleDelegate& InDelegate)
	{
		FZThreadHandle Threadhandle;

		{
			MUTEX_LOCK;

			for (auto& Tmp : *this)
			{
				if (Tmp->IsSuspend() && !Tmp->GetDelegate().IsBound())
				{
					Tmp->GetDelegate() = InDelegate;
					Threadhandle = Tmp->GetThreadHandle().Get();
					break;
				}
			}
		}

		if (!Threadhandle.IsValid())
		{
			//����һ���Զ�������߳�
			*this << MakeShareable(new FZThreadRunnable) << InDelegate;
		}

		return Threadhandle;
	}

	/* ���̳߳��в����߳� */
	TSharedPtr<IThreadProxy> operator>> (const FZThreadHandle& InHandle)
	{
		MUTEX_LOCK;

		for (auto& Tmp : *this)
		{
			if (Tmp->GetThreadHandle().Get() == InHandle)
			{
				return Tmp;
			}
		}

		return nullptr;
	}
};

class ZTHREAD_API IThreadTaskContainer : public TQueue<FSimpleDelegate>, public TArray<TSharedPtr<IThreadProxy>>, public IThreadContainer
{
protected:
	typedef TQueue<FSimpleDelegate>					TTaskQueue;
	typedef TArray<TSharedPtr<IThreadProxy>>		TTaskArray;

public:

	/* ���ӵ�������� */
	void operator<< (const FSimpleDelegate& InDelegate)
	{
		MUTEX_LOCK;
		this->Enqueue(InDelegate);
	}

	/* �Ӷ���ȡ������ */
	bool operator<<= (FSimpleDelegate& OutDelegate)
	{
		MUTEX_LOCK;
		return this->Dequeue(OutDelegate);
	}

	/************************************************************
	*	�����̵߳��̳߳�
	*	֧����ʽ���
	************************************************************/
	IThreadTaskContainer& operator<< (const TSharedPtr<IThreadProxy>& InThreadProxy)
	{
		MUTEX_LOCK;
		(*this).Add(InThreadProxy);

		return *this;
	}

	/* ���ҿ����̰߳������޿����߳�ʱ�����ӵ�������� */
	void operator>> (const FSimpleDelegate& InDelegate)
	{
		bool bSuccessful = false;
		{
			MUTEX_LOCK;

			for (auto& Tmp : *this)
			{
				if (Tmp->IsSuspend() && !Tmp->GetDelegate().IsBound())
				{
					Tmp->GetDelegate() = InDelegate;
					Tmp->WakeupThread();
					bSuccessful = true;
					break;
				}
			}

			if (!bSuccessful)
			{
				*this << InDelegate;
			}
		}
	}

};

class ZTHREAD_API IAbandonableContainer : public IThreadContainer
{
public:

	/* ͬ�� */
	void operator<< (const FSimpleDelegate& InDelegate)
	{
		FAsyncTask<FZAbandonable>* SyncAbandThread = new FAsyncTask<FZAbandonable>(InDelegate); 
		SyncAbandThread->StartBackgroundTask(); 
		SyncAbandThread->EnsureCompletion(); 
		delete SyncAbandThread;
	}

	/* �첽 */
	void operator>> (const FSimpleDelegate& InDelegate)
	{
		(new FAutoDeleteAsyncTask<FZAbandonable>(InDelegate))->StartBackgroundTask();
	}
	
};

class ZTHREAD_API ICoroutineContainer
{
public:

	ICoroutineContainer()
		:TmpTotalTime(0.f)
	{}

	~ICoroutineContainer()
	{
		ICoroutineObj::CoroutineObjArray.Empty();
	}

	/* ����TmpTotalTime */
	ICoroutineContainer& operator<< (float InTotalTime)
	{
		TmpTotalTime = InTotalTime;
		return *this;
	}

	/* ����������ʱ��FCoroutineObj�������ӵ����� */
	ICoroutineContainer& operator<< (const FSimpleDelegate& InDelegate)
	{
		ICoroutineObj::CoroutineObjArray.Add(MakeShareable(new FCoroutineObj(TmpTotalTime, InDelegate)));
		return *this;
	}

	/* ��������û����ʱ��FCoroutineObj�������ӵ����� */
	FCoroutineHandle operator>> (const FSimpleDelegate& InDelegate)
	{
		ICoroutineObj::CoroutineObjArray.Add(MakeShareable(new FCoroutineObj(InDelegate)));
		return ICoroutineObj::CoroutineObjArray[ICoroutineObj::CoroutineObjArray.Num() - 1];
	}

	/* �������������еĴ��������д�������ʱʱ���ѵ�ʱ��ִ�У���ɾ�� */
	void operator<<= (float InTime)
	{
		TArray<TSharedPtr<ICoroutineObj>> RemoveItems;
		for (int32 i = 0; i < ICoroutineObj::CoroutineObjArray.Num(); i++)
		{
			FCoroutineRequest Request(InTime);
			ICoroutineObj::CoroutineObjArray[i]->Update(Request);
			if (Request.bCompleteRequest)
			{
				RemoveItems.Add(ICoroutineObj::CoroutineObjArray[i]);
			}
		}

		for (auto& Item : RemoveItems)
		{
			ICoroutineObj::CoroutineObjArray.Remove(Item);
		}
	}

private:
	float TmpTotalTime;
};

class ZTHREAD_API IGraphContainer : public IThreadContainer
{
protected:

	/* ���߳� */
	FGraphEventRef operator<< (const FSimpleDelegate& InDelegate)
	{
		MUTEX_LOCK;
		FSimpleDelegateGraphTask::CreateAndDispatchWhenReady(
			InDelegate,
			TStatId(),
			nullptr,
			ENamedThreads::GameThread);
	}

	/* �����߳� */
	FGraphEventRef operator>> (const FSimpleDelegate& InDelegate)
	{
		MUTEX_LOCK;
		FSimpleDelegateGraphTask::CreateAndDispatchWhenReady(
			InDelegate,
			TStatId(),
			nullptr,
			ENamedThreads::AnyThread);
	}

};

class ZTHREAD_API IStreamableContainer
{
public:

	virtual ~IStreamableContainer() {}

	/* ����·�� */
	IStreamableContainer& operator>> (const TArray<FSoftObjectPath>& InObjPaths)
	{
		SetObjpath(InObjPaths);

		return *this;
	}

	/* �첽���� */
	TSharedPtr<FStreamableHandle> operator>> (const FSimpleDelegate& InDelegate)
	{
		return (GetStreamableManage()->RequestAsyncLoad(GetObjPaths(), InDelegate));
	}

	/* ͬ������ */
	TSharedPtr<FStreamableHandle> operator<< (const TArray<FSoftObjectPath>& InObjPaths)
	{
		return (GetStreamableManage()->RequestSyncLoad(InObjPaths));
	}

protected:

	virtual void SetObjpath(const TArray<FSoftObjectPath>& InObjPaths) = 0;
	virtual TArray<FSoftObjectPath>& GetObjPaths() = 0;
	virtual FStreamableManager* GetStreamableManage() = 0;

};