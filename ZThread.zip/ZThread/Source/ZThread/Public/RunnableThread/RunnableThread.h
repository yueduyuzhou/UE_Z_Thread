#pragma once

#include "CoreMinimal.h"
#include "HAL/Runnable.h"
#include "ThreadInterface/IThreadProxy.h"
#include "UObject/NameTypes.h"
#include "HAL/RunnableThread.h"
#include "Core/ZthreadSemaphore.h"

class ZTHREAD_API FZThreadRunnable : public FRunnable, public IThreadProxy
{
public:
	FZThreadRunnable(bool InbSusbendAtFirst = false);
	~FZThreadRunnable();

	virtual void CreateSafeThread();
	virtual void WakeupThread();
	virtual bool IsSuspend();
	virtual void WaitAndCompleted();
	virtual void BlockingAndCompletion();

private:

	virtual bool Init();
	virtual uint32 Run();
	virtual void Stop();
	virtual void Exit();

private:

	FThreadSafeCounter				StopTaskCounter;	//�Ƿ������߳�
	bool							bSuspenAtFirst;		//�Ƿ�����߳�
	FRunnableThread*				ThreadIns;			//�̵߳�ʵ��
	FName							ThreadName;			//�̵߳�����

	FZThreadSemaphore				ThreadEvent;		//
	FZThreadSemaphore				StartupEvent;		//�������̵߳��߳��¼�
	FZThreadSemaphore				WaitExcuteEvent;	//
	FCriticalSection				Mutex;

	static int32					ThreadCount;		//�̼߳���
};