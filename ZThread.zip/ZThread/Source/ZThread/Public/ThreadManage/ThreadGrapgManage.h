#pragma once

#include "CoreMinimal.h"
#include "ManageBase/ManageBase.h"

struct ZTHREAD_API FGraphManagement : public FManageBase<IGraphContainer, FGraphEventRef>
{
public:

	static void Wait(const FGraphEventRef& InGraphEvent)
	{
		FTaskGraphInterface::Get().WaitUntilTaskCompletes(InGraphEvent);
	}

	static void Wait(const FGraphEventArray& InGraphEvents)
	{
		FTaskGraphInterface::Get().WaitUntilTasksComplete(InGraphEvents);
	}

};