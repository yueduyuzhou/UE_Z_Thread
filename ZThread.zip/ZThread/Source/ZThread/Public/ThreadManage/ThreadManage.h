#pragma once

#include "CoreMinimal.h"
#include "ThreadManage\ThreadProxyManage.h"
#include "ThreadManage\ThreadTaskManage.h"
#include "ThreadManage\ThreadAbandonableManage.h"
#include "ThreadManage\ThreadCoroutineManage.h"
#include "ThreadManage\ThreadGrapgManage.h"

class IThreadProxy;
struct FZThreadHandle;
struct FAbandonableManagement;

namespace TM
{
	/************************************************************
	*
	*	����
	*	�̰߳�ȫ
	*
	************************************************************/
	class ZTHREAD_API FThreadManagement : public TSharedFromThis<FThreadManagement>, public FTickableGameObject
	{
	public:

		static TSharedRef<FThreadManagement> Get();
		static void Destroy();

		static FThreadProxyManagement& GetProxyManage() { return Get()->ProxyManager; }
		static FThreadTaskManagement& GetTaskManage() { return Get()->TaskManager; }
		static FAbandonableManagement& GetAbandonableManage() { return Get()->AbandonableManager; }
		static FCoroutineManagement& GetCoroutineManage() { return Get()->CoroutineManager; }
		static FGraphManagement& GetGraphManage() { return Get()->GraphManager; }
		//static FResourceLoadingManagement& GetResourceLoadingManage() { return Get()->ResourceLoadingManager; }

	private:

		virtual void Tick(float DeltaTime);
		virtual TStatId GetStatId() const;

	protected:

		FThreadProxyManagement ProxyManager;
		FThreadTaskManagement TaskManager;
		FAbandonableManagement AbandonableManager;
		FCoroutineManagement CoroutineManager;
		FGraphManagement GraphManager;
		//FResourceLoadingManagement ResourceLoadingManager;

	private:

		static TSharedPtr<FThreadManagement> ThreadManager;
	};
}

using namespace TM;

typedef TM::FThreadManagement GThread;