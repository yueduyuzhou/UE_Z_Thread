#pragma once

#include "CoreMinimal.h"
#include "ManageBase/ManageBase.h"
#include "ThreadInterface/IThreadManage.h"

struct ZTHREAD_API FCoroutineManagement : public FManageAsyncBase<ICoroutineContainer, FCoroutineHandle>
{
public:

	FCoroutineManagement();

	void Tick(float DeltaTime);

	/************************************************************
	*	ͬ�� "<<"
	************************************************************/
	template<class UserClass, typename... VarTypes>
	FCoroutineHandle CreateSyncRaw(float InTotalTime, UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << InTotalTime <<  FSimpleDelegate::CreateRaw(InUserClass, InMethod, Vars...);
	}

	template<class UserClass, typename... VarTypes>
	FCoroutineHandle CreateSyncUObj(float InTotalTime, UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << InTotalTime << FSimpleDelegate::CreateUObject(InUserClass, InMethod, Vars...);
	}

	template<class UserClass, typename... VarTypes>
	FCoroutineHandle CreateSyncUFunc(float InTotalTime, UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << InTotalTime << FSimpleDelegate::CreateUFunction(InUserClass, InMethod, Vars...);
	}

	template<class UserClass, typename... VarTypes>
	FCoroutineHandle CreateSyncSP(float InTotalTime, UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << InTotalTime << FSimpleDelegate::CreateSP(InUserClass, InMethod, Vars...);
	}

	template<class UserClass, typename... VarTypes>
	FCoroutineHandle CreateSyncLambda(float InTotalTime, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << InTotalTime << FSimpleDelegate::CreateLambda(InMethod, Vars...);
	}
};
