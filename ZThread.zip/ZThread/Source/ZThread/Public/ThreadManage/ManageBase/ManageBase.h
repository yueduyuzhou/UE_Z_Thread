#pragma once

#include "CoreMinimal.h"

template<class FTask, typename ReturnType = void>
class ZTHREAD_API FManageAsyncBase : public FTask
{
public:

	FManageAsyncBase()
		:FTask()
	{}

	/************************************************************
	*	�첽 ">>"
	************************************************************/
	template<class UserClass, typename... VarTypes>
	ReturnType CreateAsyncRaw(UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this >> FSimpleDelegate::CreateRaw(InUserClass, InMethod, InVars...);
	}

	template<class UserClass, typename... VarTypes>
	ReturnType CreateAsyncUObj(UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this >> FSimpleDelegate::CreateUObject(InUserClass, InMethod, InVars...);
	}

	template<class UserClass, typename... VarTypes>
	ReturnType CreateAsyncUFunc(UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this >> FSimpleDelegate::CreateUFunction(InUserClass, InMethod, InVars...);
	}

	template<class UserClass, typename... VarTypes>
	ReturnType CreateAsyncSP(UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this >> FSimpleDelegate::CreateSP(InUserClass, InMethod, InVars...);
	}

	template<class UserClass, typename... VarTypes>
	ReturnType CreateAsyncLambda(typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this >> FSimpleDelegate::CreateLambda(InMethod, InVars...);
	}
};

template<class FTask, typename ReturnType = void>
class ZTHREAD_API FManageBase : public FManageAsyncBase<FTask, ReturnType>
{
public:

	FManageBase()
		:FManageAsyncBase<FTask, ReturnType>()
	{}

	/************************************************************
	*	ͬ�� "<<"
	************************************************************/
	template<class UserClass, typename... VarTypes>
	ReturnType CreateSyncRaw(UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << FSimpleDelegate::CreateRaw(InUserClass, InMethod, Vars...);
	}

	template<class UserClass, typename... VarTypes>
	ReturnType CreateSyncUObj(UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << FSimpleDelegate::CreateUObject(InUserClass, InMethod, Vars...);
	}

	template<class UserClass, typename... VarTypes>
	ReturnType CreateSyncUFunc(UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << FSimpleDelegate::CreateUFunction(InUserClass, InMethod, Vars...);
	}

	template<class UserClass, typename... VarTypes>
	ReturnType CreateSyncSP(UserClass* InUserClass, typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << FSimpleDelegate::CreateSP(InUserClass, InMethod, Vars...);
	}

	template<class UserClass, typename... VarTypes>
	ReturnType CreateSyncLambda(typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type InMethod, VarTypes... InVars)
	{
		return *this << FSimpleDelegate::CreateLambda(InMethod, Vars...);
	}
};