#pragma once

#include "CoreMinimal.h"
#include "ThreadInterface/IThreadManage.h"
#include "ManageBase/ManageBase.h"

struct FZThreadHandle;

class ZTHREAD_API FThreadTaskManagement : public FManageBase<IThreadTaskContainer>
{
public:
	FThreadTaskManagement();
	~FThreadTaskManagement();

	void Init(int32 InThradNum);

public:

	void Tick(float DeltaTime);

};