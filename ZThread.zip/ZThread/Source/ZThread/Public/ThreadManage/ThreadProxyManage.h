#pragma once

#include "CoreMinimal.h"
#include "ThreadInterface/IThreadManage.h"
#include "ManageBase/ManageBase.h"

class ZTHREAD_API FThreadProxyManagement : public FManageBase<IThreadProxyContainer, FZThreadHandle>
{
public:

	~FThreadProxyManagement();

public:

	bool Join(FZThreadHandle InHandle);					//ͬ��
	bool Detach(FZThreadHandle InHandle);				//�첽
	EThreadState Joinable(FZThreadHandle InHandle);


};