#pragma once

#include "CoreMinimal.h"
#include "ManageBase/ManageBase.h"

struct ZTHREAD_API FAbandonableManagement : public FManageBase<IAbandonableContainer>
{

};