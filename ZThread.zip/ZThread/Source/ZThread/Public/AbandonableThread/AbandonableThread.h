#pragma once

#include "CoreMinimal.h"

struct ZTHREAD_API FZAbandonable : public FNonAbandonableTask
{
public:

	FZAbandonable(const FSimpleDelegate& InDelegate);

	void DoWork();

	FORCEINLINE TStatId GetStatId() const
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FZAbandonable, STATGROUP_ThreadPoolAsyncTasks);
	}

private:

	FSimpleDelegate ThreadDelegate;
};