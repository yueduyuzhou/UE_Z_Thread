#include "AbandonableThread/AbandonableThread.h"

FZAbandonable::FZAbandonable(const FSimpleDelegate& InDelegate)
	:ThreadDelegate(InDelegate)
{

}

void FZAbandonable::DoWork()
{
	ThreadDelegate.ExecuteIfBound();
}

