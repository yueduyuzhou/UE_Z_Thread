#include "ThreadManage/ThreadManage.h"
#include "ThreadInterface/IThreadProxy.h"
#include "Core/ZThreadType.h"
#include "RunnableThread/RunnableThread.h"
#include "ThreadInterface/IThreadManage.h"

TSharedPtr<FThreadManagement> FThreadManagement::ThreadManager = nullptr;

TSharedRef<FThreadManagement> FThreadManagement::Get()
{
	if (!ThreadManager.IsValid())
	{
		ThreadManager = MakeShareable(new FThreadManagement);
	}

	return ThreadManager.ToSharedRef();
}

void FThreadManagement::Destroy()
{
	if (ThreadManager.IsValid())
	{
		ThreadManager = nullptr;
	}
}

void FThreadManagement::Tick(float DeltaTime)
{
	//������й���
	TaskManager.Tick(DeltaTime);
	//Э�̹���
	CoroutineManager.Tick(DeltaTime);
}

TStatId FThreadManagement::GetStatId() const
{
	return TStatId();
}
