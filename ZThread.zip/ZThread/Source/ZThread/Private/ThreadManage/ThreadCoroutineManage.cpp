#include "ThreadManage/ThreadCoroutineManage.h"

FCoroutineManagement::FCoroutineManagement()
	:FManageAsyncBase<ICoroutineContainer, FCoroutineHandle>()
{

}

void FCoroutineManagement::Tick(float DeltaTime)
{
	*this <<= DeltaTime;
}

