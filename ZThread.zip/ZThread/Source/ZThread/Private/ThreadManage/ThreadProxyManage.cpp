#include "ThreadManage/ThreadProxyManage.h"
#include "Core/ZThreadType.h"
#include "ThreadInterface/IThreadProxy.h"

FThreadProxyManagement::~FThreadProxyManagement()
{
	for (auto& Tmp : *this)
	{
		Tmp->WaitAndCompleted();
	}

	this->Empty();
}

bool FThreadProxyManagement::Join(FZThreadHandle InHandle)
{
	MUTEX_LOCK;

	if (InHandle.IsValid())
	{
		TSharedPtr<IThreadProxy> ThreadProxy = *this >> InHandle;
		ThreadProxy->BlockingAndCompletion();

		return true;
	}
	
	return false;
}

bool FThreadProxyManagement::Detach(FZThreadHandle InHandle)
{
	MUTEX_LOCK;

	if (InHandle.IsValid())
	{
		TSharedPtr<IThreadProxy> ThreadProxy = *this >> InHandle;
		ThreadProxy->WakeupThread();

		return true;
	}

	return false;
}

EThreadState FThreadProxyManagement::Joinable(FZThreadHandle InHandle)
{
	TSharedPtr<IThreadProxy> ThreadProxy = *this >> InHandle;

	if (ThreadProxy.IsValid())
	{
		if (ThreadProxy->IsSuspend())
		{
			return EThreadState::THREADLISURELY;
		}
		else
		{
			return EThreadState::THREADWORKING;
		}
	}

	return EThreadState::THREADERROR;
}

