#include "ThreadManage/ThreadTaskManage.h"
#include "ThreadInterface/IThreadProxy.h"
#include "RunnableThread/RunnableThread.h"


FThreadTaskManagement::FThreadTaskManagement()
{
	Init(CPUThreadNumber);
}

FThreadTaskManagement::~FThreadTaskManagement()
{
	for (auto& Tmp : *this)
	{
		Tmp->WaitAndCompleted();
	}

	((TTaskQueue*)this)->Empty();
	((TTaskArray*)this)->Empty();
}

void FThreadTaskManagement::Init(int32 InThradNum)
{
	for (int32 i = 0; i < InThradNum; i++)
	{
		*this << MakeShareable(new FZThreadRunnable);
	}
}

void FThreadTaskManagement::Tick(float DeltaTime)
{
	TSharedPtr<IThreadProxy> ThreadProxy = nullptr;
	{
		MUTEX_LOCK;
		for (auto& Tmp : *this)
		{
			if (Tmp->IsSuspend())
			{
				ThreadProxy = Tmp;
				break;
			}
		}
	}

	if (ThreadProxy.IsValid())
	{
		if (!(((TTaskQueue*)this)->IsEmpty()))
		{
			FSimpleDelegate Delegate;
			if (*this <<= Delegate)
			{
				MUTEX_LOCK;
				ThreadProxy->GetDelegate() = Delegate;
				ThreadProxy->WakeupThread();
			}
		}
	}
}

