#include "Core/ZthreadSemaphore.h"

FZThreadSemaphore::FZThreadSemaphore()
	:EventSemaphore(FPlatformProcess::GetSynchEventFromPool())
{

}

FZThreadSemaphore::~FZThreadSemaphore()
{
	FPlatformProcess::ReturnSynchEventToPool(EventSemaphore);
}

void FZThreadSemaphore::Trigger()
{
	EventSemaphore->Trigger();
	bWait = false;
}

bool FZThreadSemaphore::Wait(uint32 WaitTime, const bool bIgnoreThreadIdleStats /*= false*/)
{
	bWait = true;
	return EventSemaphore->Wait(WaitTime, bIgnoreThreadIdleStats);
}

bool FZThreadSemaphore::Wait()
{
	bWait = true;
	return EventSemaphore->Wait();
}

