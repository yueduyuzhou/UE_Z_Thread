#include "Core/ZThreadType.h"

uint64 SpawnRandomInt()
{
	return FMath::Abs(FMath::RandRange(100, 1234567) + FDateTime::Now().GetTicks());
}

FZThreadHandle::FZThreadHandle()
{
	GID_A = SpawnRandomInt();
	GID_B = SpawnRandomInt();
	GID_C = SpawnRandomInt();
	GID_D = SpawnRandomInt();

	bIsValid = true;
}

