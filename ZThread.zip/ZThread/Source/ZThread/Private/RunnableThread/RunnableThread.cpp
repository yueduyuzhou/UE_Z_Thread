#include "HAL/RunnableThread.h"
#include "RunnableThread/RunnableThread.h"
#include "Core/ZThreadType.h"
#include "Containers/UnrealString.h"

IThreadProxy::IThreadProxy()
{
	ThreadHandle = MakeShared<FZThreadHandle>();
}

IThreadProxy::~IThreadProxy()
{

}

int32 FZThreadRunnable::ThreadCount = 0;

FZThreadRunnable::FZThreadRunnable(bool InbSusbendAtFirst /* = false */)
	:IThreadProxy(),
	StopTaskCounter(0),
	bSuspenAtFirst(InbSusbendAtFirst),
	ThreadIns(nullptr)
{

}

FZThreadRunnable::~FZThreadRunnable()
{

	if (ThreadIns != nullptr)
	{
		delete ThreadIns;
		ThreadIns = nullptr;
	}
}

bool FZThreadRunnable::Init()
{
	if (!FPlatformProcess::SupportsMultithreading())
	{
		Stop();
	}

	return StopTaskCounter.GetValue() == 0;
}

uint32 FZThreadRunnable::Run()
{
	while (StopTaskCounter.GetValue() == 0)
	{
		if (bSuspenAtFirst)
		{
			ThreadEvent.Wait();
		}

		bSuspenAtFirst = false;

		if (ThreadDelegate.IsBound())
		{
			ThreadDelegate.Execute();

			ThreadDelegate.Unbind();
		}

		//����ͬ���������߳�
		WaitExcuteEvent.Trigger();

		//�����߳�
		bSuspenAtFirst = true;
	}

	return 0;
}

void FZThreadRunnable::Stop()
{
	StopTaskCounter.Increment();
}

void FZThreadRunnable::Exit()
{
	StartupEvent.Trigger();
}

void FZThreadRunnable::CreateSafeThread()
{
	ThreadCount++;
	ThreadName = *(TEXT("ZThread-") + FString::Printf(TEXT("%i"), ThreadCount));

	ThreadIns = FRunnableThread::Create(this, *(ThreadName.ToString()), 0, TPri_BelowNormal);
}

void FZThreadRunnable::WakeupThread()
{
	ThreadEvent.Trigger();
}

bool FZThreadRunnable::IsSuspend()
{
	return bSuspenAtFirst;
}

void FZThreadRunnable::WaitAndCompleted()
{
	Stop();

	ThreadEvent.Trigger();

	StartupEvent.Wait();

	FPlatformProcess::Sleep(0.03f);
}

void FZThreadRunnable::BlockingAndCompletion()
{
	//����סͬ�������߳�
	WaitExcuteEvent.Wait();
}

