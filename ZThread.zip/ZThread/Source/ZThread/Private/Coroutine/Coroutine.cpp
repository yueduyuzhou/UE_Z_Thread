#include "Coroutine/Coroutine.h"

TArray<TSharedPtr<ICoroutineObj>> ICoroutineObj::CoroutineObjArray;

FCoroutineRequest::FCoroutineRequest(const float InIntervalTime)
	:bCompleteRequest(false),
	IntervalTime(InIntervalTime)
{

}

ICoroutineObj::ICoroutineObj()
	:bAwaken(false)
{

}

FCoroutineObj::FCoroutineObj(const FSimpleDelegate& InDelegate)
	:ICoroutineObj(),
	Delegate(InDelegate),
	TotalTime(INDEX_NONE),
	RuningTime(0)
{
	CoroutineObjArray.Add(this->AsShared());
}

FCoroutineObj::FCoroutineObj(const float InTotalTime, const FSimpleDelegate& InDelegate)
	:ICoroutineObj(),
	Delegate(InDelegate),
	TotalTime(InTotalTime),
	RuningTime(0)
{
	CoroutineObjArray.Add(this->AsShared());
}

void FCoroutineObj::Update(FCoroutineRequest& InCoroutineRequest)
{
	if (TotalTime != INDEX_NONE)
	{
		RuningTime += InCoroutineRequest.IntervalTime;
		if (RuningTime >= TotalTime)
		{
			Delegate.ExecuteIfBound();
			InCoroutineRequest.bCompleteRequest = true;
		}
	}
	else
	{
		if ((bool)bAwaken == true)
		{
			Delegate.ExecuteIfBound();
			InCoroutineRequest.bCompleteRequest = true;
		}
	}
}
